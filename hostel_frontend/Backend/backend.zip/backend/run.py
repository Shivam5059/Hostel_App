from app import app
import os

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    print(f"🚀 Server ready at http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
